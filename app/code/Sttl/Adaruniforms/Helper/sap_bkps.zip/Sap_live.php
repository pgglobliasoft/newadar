<?php
namespace Sttl\Adaruniforms\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Zend\Db\Adapter\Adapter;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session;
use Magento\Framework\Pricing\Helper\Data;
use Magento\Framework\App\Filesystem\DirectoryList;
class Sap extends AbstractHelper
{  
	const LOG_FILE_NAME = 'Query.log';
    /** 
     * @var EncryptorInterface
     */
    protected $scopeConfig; 
	
	protected $_storeManager;

	protected $adapter;
	 
	protected $_session; 
	
	protected $_customerRepositoryInterface;

	protected $pricingHelperData;

	protected $_filesystem;
	
	protected $productFactory;
	protected $directoryList;
    /**
     * @param Context $context
     * @param EncryptorInterface $encryptor
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
		Data $pricingHelperData,
		DirectoryList $directoryList,
		\Magento\Framework\Filesystem $filesystem,
		\Magento\Customer\Model\Session $session,
		\Magento\Catalog\Model\ProductFactory $productFactory,
		\Psr\Log\LoggerInterface $logger,
		\Sttl\Adaruniforms\Helper\Data $helper
    )
    {
		$this->_storeManager = $storeManager;
		$this->directoryList = $directoryList;
		$this->_customerRepositoryInterface = $customerRepositoryInterface;
		$this->_session = $session;
        $this->scopeConfig = $scopeConfig;
        $this->pricingHelperData = $pricingHelperData;
        $this->_filesystem = $filesystem;
        $this->productFactory = $productFactory;
        $this->logger = $logger;
        $this->logger->pushHandler(new \Monolog\Handler\StreamHandler($this->directoryList->getRoot().'/var/log/'.self::LOG_FILE_NAME));
        $this->helper = $helper;
        parent::__construct($context);
        
		/**if($_SERVER['SERVER_ADDR'] == '10.64.32.178') {
			
			$this->adapter = new \Zend\Db\Adapter\Adapter([
				'driver'   => 'Sqlsrv',
				'hostname' => '108.29.175.58',
				'database' => 'Adar_Medical_Uniforms',
				'username' => 'sa',
				'password' => 'Adar9876',
			]);
		} else {
			$this->adapter = new \Zend\Db\Adapter\Adapter([
				'driver'   => 'Sqlsrv',
				'hostname' => '192.168.0.92',
				'database' => 'Adar_Medical_Uniforms',
				'username' => 'sa',
				'password' => 'ibm@@123',
				
			]); 
		}**/
		$this->adapter = new \Zend\Db\Adapter\Adapter([
				'driver'   => 'Sqlsrv',
				'hostname' => $this->helper->getConfigData("Adaruniforms/sap_server_onfiguration/server_ip"),
				'database' => $this->helper->getConfigData("Adaruniforms/sap_server_onfiguration/db_name"),
				'username' => $this->helper->getConfigData("Adaruniforms/sap_server_onfiguration/username"),
				'password' => $this->helper->getConfigData("Adaruniforms/sap_server_onfiguration/password"),
				]); 
    }

    /*
     * @return bool
     */
    
     public function getCustomerDetailsbyid($id)
    {
    	$customer = $this->_customerRepositoryInterface->getById($id);
		//$getData = $this->_session->getCustomer()->getData();
		$customer_number = $customer->getCustomAttribute('customer_number')->getValue();
		$webaccess_code = $customer->getCustomAttribute('webaccess_code')->getValue();
		$query = "SELECT * FROM dbo.MWEB_OCRD where dbo.MWEB_OCRD.CardCode = '".$customer_number."' AND dbo.MWEB_OCRD.WebAccessCode = '".$webaccess_code."' ";
		return $this-> getSapData($query);
    }
    public function getCustomerDetails($fields = array())
    {
		$fields_select = '*';
		if(!empty($fields) && count($fields) > 0)
		{
			$fields_select = implode(', ',$fields);
		}
    	$customer = $this->_customerRepositoryInterface->getById($this->_session->getCustomer()->getId());
		//$getData = $this->_session->getCustomer()->getData();
		$customer_number = $customer->getCustomAttribute('customer_number')->getValue();
		$webaccess_code = $customer->getCustomAttribute('webaccess_code')->getValue();
		$query = "SELECT $fields_select FROM dbo.MWEB_OCRD where dbo.MWEB_OCRD.CardCode = '".$customer_number."' AND dbo.MWEB_OCRD.WebAccessCode = '".$webaccess_code."' ";
		return $this-> getSapData($query);
    }
    public function getponumberlist($customdata)
    {
		$query = "SELECT * FROM dbo.MWEB_Temp_ORDR where dbo.MWEB_Temp_ORDR.CardCode = '".$customdata['CardCode']."' And dbo.MWEB_Temp_ORDR.DocStatus = 'Draft'";
		return $this-> getSapData($query);
    }
    public function getCountryList()
    {
		$query = "SELECT * FROM dbo.MWEB_Country  ORDER BY dbo.MWEB_Country.CountryName ASC";
		return $this-> getSapData($query);
    }
     public function getcontryinfo($contryCode)
    {
		$query = "SELECT * FROM dbo.MWEB_Country where dbo.MWEB_Country.CountryCode = '".$contryCode."'";
		return $this-> getSapData($query);
    }
    public function getStateList()
    {
		$query = "SELECT * FROM dbo.MWEB_State  ORDER BY dbo.MWEB_State.StateCode ASC";
		return $this-> getSapData($query);
    }
    public function getstateinfo($stateCode)
    {
		$query = "SELECT * FROM dbo.MWEB_State where dbo.MWEB_State.StateCode = '".$stateCode."'";
		return $this-> getSapData($query);
    }
	public function checkponumber($customdata,$po_number)
    {
    	//$query = "SELECT * FROM dbo.MWEB_Temp_ORDR where dbo.MWEB_Temp_ORDR.CardCode = '".$customdata['CardCode']."' AND dbo.MWEB_Temp_ORDR.NumatCardPo = '".$po_number."' ";
		$query = "SELECT dbo.MWEB_Temp_ORDR.NumatCardPo FROM dbo.MWEB_Temp_ORDR where dbo.MWEB_Temp_ORDR.CardCode = '".$customdata['CardCode']."' AND dbo.MWEB_Temp_ORDR.NumatCardPo = '".$po_number."' UNION SELECT dbo.MWEB_ORDR.NumatCardPo FROM dbo.MWEB_ORDR where dbo.MWEB_ORDR.CardCode = '".$customdata['CardCode']."' AND dbo.MWEB_ORDR.NumatCardPo = '".$po_number."' ";
		return $this-> getSapData($query);
    }
    
	public function insertdataordr($customdata,$po_number,$OrderMethod = "")
    {
    	$orderData = $this->getSapOrdersData($customdata,$po_number);
    	if(empty($orderData[0]))
        {
        	$customdata['CardName'] = str_replace("'",' ',$customdata['CardName']);
        	$query = "INSERT INTO dbo.MWEB_Temp_ORDR (CardCode,CardName,NumatCardPo,DocStatus, CreateDate, CreateTs, u_jk_order_method,UpdateDate, UpdateTs) VALUES('".$customdata['CardCode']."','".$customdata['CardName']."','".$po_number."','Draft', '".date("m-d-Y")."', '".date("H:i:s")."','".$OrderMethod."', '".date("m-d-Y")."', '".date("H:i:s")."')";
        	return  $this-> insertSapData($query);
        }else{
        	$orderData = $orderData[0];
        	$customdata['CardName'] = str_replace("'",' ',$customdata['CardName']);
        	$query = "UPDATE dbo.MWEB_Temp_ORDR SET dbo.MWEB_Temp_ORDR.CardCode = '".$customdata['CardCode']."', dbo.MWEB_Temp_ORDR.CardName = '".$customdata['CardName']."',dbo.MWEB_Temp_ORDR.NumatCardPo = '".$po_number."',dbo.MWEB_Temp_ORDR.DocStatus = 'Draft',dbo.MWEB_Temp_ORDR.CreateDate = '".date("m-d-Y")."',dbo.MWEB_Temp_ORDR.CreateTs = '".date("H:i:s")."',dbo.MWEB_Temp_ORDR.u_jk_order_method = '".$OrderMethod."',dbo.MWEB_Temp_ORDR.UpdateDate = '".date("m-d-Y")."',dbo.MWEB_Temp_ORDR.UpdateTs = '".date("H:i:s")."' WHERE dbo.MWEB_Temp_ORDR.Id= '".$orderData['Id']."'";
        	 $this-> insertSapData($query);
        	 return $orderData['Id'];
        }
		
		
    }
    public function insertdataordritems($data,$itmesdata = array())
    {
    	if(empty($itmesdata))
    	{
    		$getColorStyleStatus = $this->getDatabyItemCode($data['itemscode']);
    		$colorStatus = $getColorStyleStatus[0]['ColorStatus'];
    		$styleStatus = $getColorStyleStatus[0]['StyleStatus'];
    		$SizeOrder = $getColorStyleStatus[0]['SizeOrder'];
    	}else{
    		$colorStatus = $itmesdata['ColorStatus'];
    		$styleStatus = $itmesdata['StyleStatus'];	
    		$SizeOrder = $itmesdata['SizeOrder'];
    	}
    	
    	
    	if($data['PriceAfterDiscount'] == '' || $data['TotalPrice'] == '' || $data['DiscountPer'])
    	{
    		$itemsdata = $this->_session->getAllInventoryItems();
    		$skudata = $itemsdata[$data['itemscode']];
    		if(!empty($skudata))
    		{
    			$data['PriceAfterDiscount'] = number_format((float)$data['QTYOrdered'] * $skudata['DisPrice'], 2, '.', '');
    			$data['TotalPrice'] = $data['PriceAfterDiscount'];
    			$data['DiscountPer'] = isset($skudata['DisPercent']) ? $skudata['DisPercent'] : "";	
    		}
    		
    	}
    	$query = "INSERT INTO dbo.MWEB_Temp_RDR1 (Style,ColorName,Size,BaseDoc,PriceAfterDiscount,TotalPrice,QTYOrdered,UnitPrice,ColorCode,ItemCode,ColorStatus,StyleStatus,SizeOrder,DiscountPer,DiscountPrice,OrderOption) VALUES('".$data['Style']."','".$data['ColorName']."','".$data['Size']."','".$data['BaseDoc']."','".$data['PriceAfterDiscount']."','".$data['TotalPrice']."','".$data['QTYOrdered']."','".$data['UnitPrice']."','".$data['colorcode']."','".$data['itemscode']."','".$colorStatus."','".$styleStatus."','".$SizeOrder."','".$data['DiscountPer']."','".$data['DisPrice']."','".$data['OrderOption']."')";
		
		return  $this-> insertSapData($query);
    }
    public function deleteordritems($enty_id,$style,$colorCondation = "")
    {
		$query = "DELETE FROM dbo.MWEB_Temp_RDR1 WHERE dbo.MWEB_Temp_RDR1.BaseDoc = '".$enty_id."' AND dbo.MWEB_Temp_RDR1.Style = '".$style."' ".$colorCondation." ";
		return  $this-> getSapData($query);
    }
    public function updateordertotal($enty_id,$totalQty = 0,$gd_total = 0,$descountPer =0,$discountAmount =0,$sellingprice = 0,$TotalDiscountPer =0,$TotalDiscountAmount =0,$customerdata)
    {
    	if(!empty($totalQty) && $totalQty != 0){
    		$getbulkdata = $this->getBulkDiscountInfo($totalQty,$customerdata);	
	    	if(!empty($getbulkdata[0]) && $getbulkdata[0] !='')
	    	{
	    		$bulkdis = (float) $getbulkdata[0]['Discount'];
				$totaldis = (float) $bulkdis + (float) $descountPer;
				$result  =  (float) $gd_total * (float) $totaldis / 100;
				$sellingprice =  $gd_total  - $result;
				if($totaldis == '.00')
				{
					$totaldis = 0;
				}
				$descountPer = $totaldis;
				$discountAmount = $result;
				//$TotalDiscountPer = $bulkdis;
				//$TotalDiscountAmount = $result ;
			}
    	}
    	 $query = "UPDATE dbo.MWEB_Temp_ORDR SET dbo.MWEB_Temp_ORDR.DocTotal = '".$sellingprice."', dbo.MWEB_Temp_ORDR.TotalBeforeDiscount = '".$gd_total."',dbo.MWEB_Temp_ORDR.TotalQTYUnits = '".$totalQty."',dbo.MWEB_Temp_ORDR.DiscountAmount = '".$discountAmount."',dbo.MWEB_Temp_ORDR.DiscountPer = '".$descountPer."',dbo.MWEB_Temp_ORDR.TotalDiscountPer = '".$TotalDiscountPer."',dbo.MWEB_Temp_ORDR.TotalDiscountAmount = '".$TotalDiscountAmount."',dbo.MWEB_Temp_ORDR.UpdateDate = '".date("m-d-Y")."',dbo.MWEB_Temp_ORDR.UpdateTs = '".date("H:i:s")."' WHERE dbo.MWEB_Temp_ORDR.Id= '".$enty_id."'";
		return $this-> insertSapData($query);
    }
    public function getBulkDiscountInfo($qty,$getLoginCUstomerData = array())
    {
    	if(empty($getLoginCUstomerData))
    	{
    		$getLoginCUstomerData = $this->getCustomerDetails();	
    		$getLoginCUstomerData = $getLoginCUstomerData[0];
    	}
    	
    	if(isset($getLoginCUstomerData) && $getLoginCUstomerData['BulkDiscount'] == true)
    	{
    		$Program = $getLoginCUstomerData['Program'];	
    		$Tier = $getLoginCUstomerData['Tier'];	
    		$query = "SELECT * from MWEB_BD where dbo.MWEB_BD.Program = '".$Program."' AND dbo.MWEB_BD.Tier = '".$Tier."' AND dbo.MWEB_BD.QtyFrom <= '".$qty."' AND dbo.MWEB_BD.QtyTo >= '".$qty."' ";
    		return  $this-> getSapData($query);
    	}
    	return '';
    }
    public function updateorderstatus($order_id)
    {
    	 $query = "UPDATE dbo.MWEB_Temp_ORDR SET dbo.MWEB_Temp_ORDR.DocStatus = 'Submitted' WHERE dbo.MWEB_Temp_ORDR.Id= '".$order_id."'";
		return $this-> insertSapData($query);
    }
    
    public function updateordershipbil($orderinfo)
    { 
    	 $query = "UPDATE dbo.MWEB_Temp_ORDR SET dbo.MWEB_Temp_ORDR.ShippingId = '".str_replace("'", "''", $orderinfo['ShippingId'])."', dbo.MWEB_Temp_ORDR.ShippingAddress = '".str_replace("'", "''", $orderinfo['ShippingAddress'])."',dbo.MWEB_Temp_ORDR.ShippingStreetNo = '".str_replace("'", "''", $orderinfo['ShippingStreetNo'])."',dbo.MWEB_Temp_ORDR.ShippingStateCode = '".$orderinfo['ShippingStateCode']."',dbo.MWEB_Temp_ORDR.ShippingState = '".$orderinfo['ShippingState']."' ,dbo.MWEB_Temp_ORDR.ShippingCity = '".str_replace("'", "''", $orderinfo['ShippingCity'])."' ,dbo.MWEB_Temp_ORDR.ShippingZip = '".$orderinfo['ShippingZip']."',dbo.MWEB_Temp_ORDR.ShippingCountryCode = '".$orderinfo['ShippingCountryCode']."'  ,dbo.MWEB_Temp_ORDR.ShippingCountry = '".$orderinfo['ShippingCountry']."' ,dbo.MWEB_Temp_ORDR.BillingName = '".str_replace("'", "''", $orderinfo['BillingName'])."',dbo.MWEB_Temp_ORDR.BillingAddress = '".str_replace("'", "''", $orderinfo['BillingAddress'])."' ,dbo.MWEB_Temp_ORDR.BillingStateCode = '".$orderinfo['BillingStateCode']."' ,dbo.MWEB_Temp_ORDR.BillingState = '".$orderinfo['BillingState']."' ,dbo.MWEB_Temp_ORDR.BillingZip = '".$orderinfo['BillingZip']."' ,dbo.MWEB_Temp_ORDR.BillingCountryCode = '".$orderinfo['BillingCountryCode']."',dbo.MWEB_Temp_ORDR.BillingCountry = '".$orderinfo['BillingCountry']."',dbo.MWEB_Temp_ORDR.BillingCity = '".str_replace("'", "''", $orderinfo['BillingCity'])."',dbo.MWEB_Temp_ORDR.CardID = '".$orderinfo['CardID']."',dbo.MWEB_Temp_ORDR.DeliveryNotes = ".$this->quoteString($orderinfo['DeliveryNotes']).",dbo.MWEB_Temp_ORDR.ShippingType = '".$orderinfo['ShippingType']."',dbo.MWEB_Temp_ORDR.Comments = '".$orderinfo['Comments']."',dbo.MWEB_Temp_ORDR.CouponCampaign = '".$orderinfo['coupon_code']."',dbo.MWEB_Temp_ORDR.BlindDropship = '".$orderinfo['BlindDropship']."',dbo.MWEB_Temp_ORDR.UpdateDate = '".date("m-d-Y")."',dbo.MWEB_Temp_ORDR.UpdateTs = '".date("H:i:s")."' WHERE dbo.MWEB_Temp_ORDR.Id= '".$orderinfo['order_id']."'";
		return $this-> insertSapData($query);
    }
    
    public function getColorbyparent($style)
    {
		$query = "SELECT DISTINCT dbo.MWEB_InventoryStatus.ColorCode , dbo.MWEB_InventoryStatus.Color , dbo.MWEB_InventoryStatus.ColorStatus , dbo.MWEB_InventoryStatus.StyleStatus ,dbo.MWEB_InventoryStatus.ColorSwatch,dbo.MWEB_InventoryStatus.Style   FROM dbo.MWEB_InventoryStatus  where dbo.MWEB_InventoryStatus.Style = '".$style."' ORDER BY dbo.MWEB_InventoryStatus.Style ASC ";
		
		return $this-> getSapData($query);
    }
     public function getColor($order_id)
    {
		
		$query = "SELECT DISTINCT dbo.MWEB_Temp_RDR1.ColorCode ,
				SUM(cast(dbo.MWEB_Temp_RDR1.TotalPrice as decimal(18,6))) as TotalPrice,dbo.MWEB_Temp_RDR1.Style,
				SUM(cast(dbo.MWEB_Temp_RDR1.QTYOrdered as int)) as TotalQuantity 
				FROM dbo.MWEB_Temp_RDR1  where dbo.MWEB_Temp_RDR1.BaseDoc = '".$order_id."' 
				group by dbo.MWEB_Temp_RDR1.ColorCode,dbo.MWEB_Temp_RDR1.Style";
		
		return $this-> getSapData($query);
    }
    public function getDatabyColor($style,$ColorCode)
    {
		$query = "SELECT * FROM dbo.MWEB_InventoryStatus  where dbo.MWEB_InventoryStatus.Style = '".$style."' AND dbo.MWEB_InventoryStatus.ColorCode = '".$ColorCode."'  ORDER BY dbo.MWEB_InventoryStatus.SizeOrder ASC";
		return $this-> getSapData($query);
    }
    public function getallitmescode()
    {
		$query = "SELECT dbo.MWEB_InventoryStatus.ItemCode,dbo.MWEB_InventoryStatus.QtyAvailable,dbo.MWEB_InventoryStatus.ETA,dbo.MWEB_InventoryStatus.UnitPrice,dbo.MWEB_InventoryStatus.DisPrice,dbo.MWEB_InventoryStatus.SizeGroup,dbo.MWEB_InventoryStatus.Style,dbo.MWEB_InventoryStatus.SizeOrder,dbo.MWEB_InventoryStatus.Size,dbo.MWEB_InventoryStatus.DisPercent FROM dbo.MWEB_InventoryStatus where dbo.MWEB_InventoryStatus.UnitPrice > 0";
		return $this-> getSapData($query);
    }
    public function checketa($style,$ColorCode)
    {
		$query = "SELECT count(dbo.MWEB_InventoryStatus.ETA) as ETAcount FROM dbo.MWEB_InventoryStatus where dbo.MWEB_InventoryStatus.Style = '".$style."' AND dbo.MWEB_InventoryStatus.ColorCode = '".$ColorCode."' AND dbo.MWEB_InventoryStatus.ETA IS NOT NULL  AND dbo.MWEB_InventoryStatus.ETA <> '' ";
		return $this-> getSapData($query);
		
    }
    
    
    /*
     * @return bool
     */
    public function checkCustomerExist($CheckSapData = "")
    {	
		$query = "SELECT * FROM dbo.MWEB_OCRD where ".$CheckSapData."";
		
		return $this-> getSapData($query);
    }
	
	public function getSapData($query = '')
	{
		if($query != '')
		{
			$this->logger->info($query);
			
			try {
				$statement = $this->adapter->query($query);
				$results = $statement->execute();
				$sap_data_array = array();
				if(isset($results) && !empty($results))
				{
					foreach($results as $sap_data)
					{
						$sap_data_array[] = $sap_data;
					}
				}
			   return $sap_data_array;
			} catch (\Exception $e) {
				$message = $e->getMessage();
				$type = 'general';
				if($message == 'Connect Error')
				{
					$message = 'Our system is currently down. Please call 718-935-1197 ext. 3 to place orders or check the status of an order.';
					$type = 'server';
				}
                $response = [
                    'errors' => true,
                    'message' => $message,
					'type' => $type
                ];
				return $response;
            }
		}
	}
	
	public function insertSapData($query = '')
	{
		if($query != '')
		{
			$this->logger->info($query);
			
			$statement = $this->adapter->query($query);
			$results = $statement->execute();
			
			return $this->adapter->getDriver()->getLastGeneratedValue();
		} else {
			return "";
		}	
	}
	
    public function getallCustomer(){
        $query = "SELECT * FROM dbo.MWEB_OCRD"; 
        return $this->getSapData($query);  
    }

    public function getCustomerByCode($code)
    {
        
        $query = "SELECT * FROM MWEB_OCRD where MWEB_OCRD.CardCode = '".$code."' ";
        return $this->getSapData($query);
    }


    public function getCustomercode(){
        $query = "SELECT CardCode,CardName FROM dbo.MWEB_OCRD";
        return $this->getSapData($query);
    }

    /*   get first customer from mweb_ocrd table if admin cusomer not have custom code */
    public function getallCustomerWithIds($all , $ids){
        if($all)    
        {            
            $query = "SELECT CardCode,CardName FROM dbo.MWEB_OCRD"; 
        }else{
            $query = "SELECT CardCode,CardName FROM dbo.MWEB_OCRD WHERE dbo.MWEB_OCRD.CardCode IN (".$ids.")";  
        }      
        return $this->getSapData($query);  
    }

   
    public function getfirstCustomerWithIds($all , $ids){
        if($all)    
        {            
            $query = "SELECT TOP 1 CardCode,CardName FROM dbo.MWEB_OCRD "; 
        }else{
            $query = "SELECT CardCode,CardName FROM dbo.MWEB_OCRD WHERE dbo.MWEB_OCRD.CardCode IN (".$ids.")";  
        }      
        return $this->getSapData($query);  
    }

	public function getCustomerShippingAddressDetails($customer_number = '')
	{
		if($customer_number == '')
		{
			$customer = $this->_customerRepositoryInterface->getById($this->_session->getCustomer()->getId());
			$getData = $this->_session->getCustomer()->getData();
			$customer_number = $customer->getCustomAttribute('customer_number')->getValue();
			if (empty($customer_number))
				return [];
		}
		//$webaccess_code = 124156;		
		$query = "SELECT * FROM dbo.MWEB_CRD1Address where dbo.MWEB_CRD1Address.CardCode = '".$customer_number."' AND AddressID IS NOT NULL";	
		
		return $this->getSapData($query);
	}

	public function renderColorHtml($style_number)
	{
		$basemedia_URL = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
		$parent_color_data = $this->getColorbyparent($style_number);
		$product = $this->productFactory->create(); 
		$product_collection_data = $product->loadByAttribute('sku', $style_number);
		$renderHtml = "";
		if(!empty($parent_color_data) && $product_collection_data !='' )
		{
			$product_collection = $product_collection_data->getAttributeText('collecttion');
			$product_name = $product_collection_data->getName();//$parent_color_data[0]['ItemName'];
			/**if(isset($parent_color_data[0]['ItemName']))
			{
				$product_name = $parent_color_data[0]['ItemName'];
			}**/
			$renderHtml .= '<h3 class="page-title"><span class="base" data-ui-id="page-title-wrapper">'.$product_name.'</span></h3>';
			$renderHtml .= '<div class="show-product-dis-box"><span>'.$product_collection.' collection </span></div>';
			$renderHtml .= '<div class="show-product-dis-box-more"><span><lable>Style: </lable></span><strong>'.$style_number.'</strong><span> Status: </span><strong id="showStyleStatus"></strong></div>';

					$renderHtml .= '<div class="swatch-opt" data-role="swatch-options">
									  <div class="swatch-attribute color" attribute-code="color" option-selected=""><span id="option-label-color-93" class="swatch-attribute-label">Color:</span><strong class="swatch-attribute-selected-option"></strong>Status: <strong id="showColorStatus"></strong>
									    <div class="swatch-attribute-options clearfix"><div id="toolTipContainer"><div id="toolTipsHeader"></div></div>';
			$fitst_cor_sel = 0;
			$seleted = 'selected';
			foreach($parent_color_data as $key => $values)
			{
				if($fitst_cor_sel > 0)
				{
					$seleted = '';		
				}

				$renderHtml .= '<div class="swatch-option image  '.$seleted.'" option-color-code ="'.$values['ColorCode'].'" id="data_from_color" option-color-status = "'.$values['ColorStatus'].'" option-style-status = "'.$values['StyleStatus'].'" tabindex="'.$key.'" option-id="'.$values['Style'].'" option-color-name = "'.$values['Color'].'" option-tooltip-thumb="'.strtolower($values['ColorSwatch']).'" option-tooltip-value="'.strtolower($values['ColorSwatch']).'" role="option" style="background: url('.strtolower($values['ColorSwatch']).') no-repeat center; background-size: initial;"></div>';
				$fitst_cor_sel++;
			}

			$renderHtml .= '</div></div></div>';
			}
		return $renderHtml;
	}

	public function renderDataByColorHtml($style_number,$getColorCode,$orderId = "", $showValue = 0)
	{
		$basemedia_URL = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
		$parent_color_data1 = $this->getColorbyparent($style_number);
		$getLoginCUstomerData = $this->getCustomerDetails();
		$FlatDiscount = $getLoginCUstomerData[0]['FlatDiscount'];
		$renderHtml = "";
			if(!empty($parent_color_data1))
			{
	                            $tr_one = '<tr><td align="right">Size</td>';
	                            $tr_two = '<tr><td align="right">Price</td>';
	                            $tr_three = '<tr><td align="right">In Stock</td>';
	                            $etacheck = '';
	                            $etacheck = $this->checketa($style_number,$getColorCode); 
	                            if(!empty($etacheck[0]['ETAcount']))
	                            {

	                                $tr_three1 = '<tr class="'.$etacheck[0]['ETAcount'].'"><td align="right" width="75">Restock Date</td>';    
	                            }
	                            
	                            $tr_four = '<tr><td align="right">Quantity</td>';
	                            $tr_five = '<tr><td align="right">Total</td>';

	                            $qty = 0.00;
	                            $extisData = array();
	                            $parent_color_data = $this->getDatabyColor($style_number,$getColorCode);
	                            $getExistingData = $this->getOrderExistingItems($orderId,$style_number,$getColorCode);
	                            foreach ($getExistingData as $keyExistingData => $valueExistingData) {
	                            	$extisData[$valueExistingData['Size']] = $valueExistingData;
	                            }

	                            foreach ($parent_color_data as $key => $value) 
	                            {
	                                $qty = (isset($value["ActualQty"]) && $value["ActualQty"] != '') ? $value["ActualQty"] : 0.00;
	                                $show_qty = (isset($value["QtyAvailable"]) && $value["QtyAvailable"] != '') ? $value["QtyAvailable"] : 0.00;
	                                //echo "<pre>";print_R($value);
	                           // if(floatval($value["QtyAvailable"]) > 0)
	                           // {
	                                $tr_one .= '<td align="center">'.$value['Size'].'</td>';
	                                if($value["UnitPrice"] > $value["DisPrice"])
									{
										$tr_two .= '<td align="center" class="disprice"><span class="mainprice">'.$this->pricingHelperData->currency($value["UnitPrice"], true, false).'</span> '.$this->pricingHelperData->currency($value["DisPrice"], true, false).' </td>';
										
									}else{
										$tr_two .= '<td align="center">'.$this->pricingHelperData->currency($value["UnitPrice"], true, false).'</td>';
										
									}
	                                if($qty > 100)
	                                {
	                                	$tr_three .= '<td align="center">'.floatval($show_qty).'+</td>';
	                                
	                                }else{
	                                	$tr_three .= '<td align="center">'.floatval($show_qty).'</td>';
	                                }
	                                if(!empty($etacheck[0]['ETAcount']))
	                                {
	                                    if(empty($value["ETA"]))
	                                    {
	                                        $tr_three1 .='<td align="center"></td>';
	                                    }else{
	                                        $tr_three1 .='<td align="center">'.date("m-d-y", strtotime($value["ETA"])).'</td>';
	                                    }
	                                }
	                                $exisQtyData = $exisTotalPriceData= "";
	                                if(isset($extisData[$value['Size']]) && $showValue == 1){
		                                $exisQtyData = $extisData[$value['Size']]['QTYOrdered'];
		                                $exisTotalPriceData = number_format( (float) $extisData[$value['Size']]['TotalPrice'], 2);
		                            }

	                                $tr_four .= '<td align="center" class="qtyTd">
	                                        <input name="qty['.$value['Color'].']['.$value['Size'].']" type="text" pattern="[0-9]" min="1" class="checkvalue" max="'.floatval($qty).'" value="'.$exisQtyData.'">
	                                            <span class="maxqtyvaldi"></span>
	                                        <input name="showprice['.$value['Color'].']['.$value['Size'].']" type="hidden" value ="'.floatval($value["DisPrice"]).'">
	                                        <input name="selectcolor" type="hidden" value ="'.$value['Color'].'">
	                                        <input name="selectsize" type="hidden" value ="'.$value['Size'].'">
	                                        <input name="itemscode['.$value['Color'].']['.$value['Size'].']" type="hidden" value ="'.$value['ItemCode'].'">
	                                        <input name="colorcode['.$value['Color'].']['.$value['Size'].']" type="hidden" value ="'.$value['ColorCode'].'">
	                                        <input name="mainprice['.$value['Color'].']['.$value['Size'].']" type="hidden" value ="'.floatval($value["UnitPrice"]).'"><input name="DiscountPer['.$value['Color'].']['.$value['Size'].']" type="hidden" value ="'.floatval($value["DisPercent"]).'">
										<input name="DiscountPrice['.$value['Color'].']['.$value['Size'].']" type="hidden" value ="'.floatval($value["DisPrice"]).'">
	                                    </td>';
	                                $tr_five .= '<td align="center" class="total"><input class="unittotal" name="inpprice['.$value['Color'].']['.$value['Size'].']" type="hidden" value ="'.$exisTotalPriceData.'"><span class="showprice">'.$exisTotalPriceData.'</span></td>';
	                          //  }
	                            }       
	                            $tr_one .= '</tr>';
	                            $tr_two .= '</tr>';
	                            $tr_three .= '</tr>';
	                            if(!empty($etacheck[0]['ETAcount']))
	                            {
	                                 $tr_three1.= '</tr>';
	                            }
	                           
	                            $tr_four .= '</tr>';
	                            $tr_five .= '</tr>';
	                            $renderHtml .= '<div class="colorContainer"><input name="changed_cart" class="changed_cart" id="changed_cart" type="hidden" value="0"><table class="table table-bordered table-responsive">';
	                            $renderHtml .= $tr_one;
	                            $renderHtml .= $tr_two;
	                            $renderHtml .= $tr_three;
	                            if(!empty($etacheck[0]['ETAcount']))
	                            {
	                                 $renderHtml .= $tr_three1;
	                            }
	                            $renderHtml .= $tr_four;
	                            $renderHtml .= $tr_five;
	                            $renderHtml .= '</table><input name="submitcolor" type="hidden" value="'.$getColorCode.'"></div>';
	                            $renderHtml .= '<input type="hidden" id="flatDiscount" name="flatDiscount" value="'.number_format((float) $FlatDiscount,2).'"><div class="alignRight"><a href="javascript:void(0);" class="saveData themeBtn">Add/Update P.O.</a></div>';
			}
		return $renderHtml;
	}
	
	public function getOrderExistingItems($order_id = "" , $style = '',$getColorCode = "", $data_from = 'T')
	{
		if($data_from == 'T')
		{
			$query = "SELECT *, dbo.MWEB_InventoryStatus.SizeOrder";
			$query .= " FROM dbo.MWEB_Temp_RDR1 ";
			$query .= " LEFT JOIN dbo.MWEB_InventoryStatus ON dbo.MWEB_Temp_RDR1.ItemCode = dbo.MWEB_InventoryStatus.ItemCode ";
			$query .= " where dbo.MWEB_Temp_RDR1.BaseDoc = '".$order_id."' AND dbo.MWEB_Temp_RDR1.Style = '".$style."' AND dbo.MWEB_Temp_RDR1.ColorCode = '".$getColorCode."' ORDER BY dbo.MWEB_InventoryStatus.SizeOrder ASC";
		}
		else
		{
			$query = "SELECT dbo.MWEB_RDR1.*, dbo.MWEB_InventoryStatus.SizeOrder";
			$query .= " FROM dbo.MWEB_RDR1 ";
			$query .= " LEFT JOIN dbo.MWEB_InventoryStatus ON dbo.MWEB_RDR1.ItemCode = dbo.MWEB_InventoryStatus.ItemCode";
			$query .= " where dbo.MWEB_RDR1.DocNum = '".$order_id."' AND dbo.MWEB_RDR1.Style = '".$style."' AND dbo.MWEB_RDR1.ColorCode = '".$getColorCode."' ORDER BY dbo.MWEB_InventoryStatus.SizeOrder ASC";
		}
		
		return $this-> getSapData($query);
	}

	public function getOrderItems($po_number = 0 , $style = '')
	{
		$query = "SELECT * FROM dbo.MWEB_Temp_RDR1 where BaseDoc = '".$po_number."' AND Style = '".$style."' ORDER BY dbo.MWEB_Temp_RDR1.Size";
		return $this-> getSapData($query);
	}

	public function getOrderSumItems($order_id = '')
	{ 
		$query = "SELECT SUM(CONVERT(float,dbo.MWEB_Temp_RDR1.TotalPrice)) AS TotalPriceOrdered FROM dbo.MWEB_Temp_RDR1 where dbo.MWEB_Temp_RDR1.BaseDoc = '".$order_id."'";
		return $this-> getSapData($query);
	}
	public function getOrderSumQty($order_id = '')
	{ 
		$query = "SELECT SUM(CONVERT(float,dbo.MWEB_Temp_RDR1.QTYOrdered)) AS TotalQtyOrdered FROM dbo.MWEB_Temp_RDR1 where dbo.MWEB_Temp_RDR1.BaseDoc = '".$order_id."'";
		return $this-> getSapData($query);
	}

	public function getDatabyStyle($styleArray = array())
    {
    	$style = "'".implode ("','", array_unique($styleArray['Style']))."'";
		$query = "SELECT DISTINCT Size, SizeOrder FROM dbo.MWEB_InventoryStatus  where Style IN (".$style.") ORDER By SizeOrder ASC";
		return $this-> getSapData($query);
    }
     public function renderOrderItemHtml($order_id = 0 , $style_number = '',$getColorCode = '',$viewMode = '')
	{
		$query = "SELECT * FROM dbo.MWEB_Temp_RDR1 where BaseDoc = '".$order_id."' ORDER BY dbo.MWEB_Temp_RDR1.Style ASC,dbo.MWEB_Temp_RDR1.ColorCode ASC";
		$getOrderData = $this-> getSapData($query);
		$renderHtml = "";
		if($getOrderData){
			$arraySize = $commanArray = array();
			foreach ($getOrderData as $key => $value) {
					$arrayStyle['Style'][] = $value['Style'];
					$commanArray[$value['Style']][$value['ColorCode']][$value['Size']] = $value;
			}
						
			$getDatabyStyle = $this->getDatabyStyle($arrayStyle);
			/* Header size parts $header_one */
			$header_one = '';
			$header_one .= '<table class="orderList lineItemsList"><tr>';
			if(empty($viewMode)){
				$header_one .= '<th width="30px"></th>';
			}
			$header_one .= '<th width="30px"></th>
						<th width="50px">Style #</th>
						<th width="50px">Color</th>';
			foreach ($getDatabyStyle as $key => $values) {
				$header_one .= '<th>'.$values['Size'].'</th>';
			}
			$header_one .= '<th width="50px">Qty.</th>
						<th width="70px">Total</th>
						<th width="50px"></th>
						</tr>';

            $renderHtml .= $header_one;
			/* Header size parts $header_one */
			$grandTotal = $total_qty = 0;
			$count = 1;

			foreach ($commanArray as $key => $value) {
				foreach ($value as $keyes => $valuees) {
				$main_tr_td = '<tr>';
				if(empty($viewMode)){
					$main_tr_td .= '<td><input type="checkbox" name="deleteMultiRecord[]" class="deleteMultiRecord" value="" /><input type="hidden" id="delete_style" name="delete_style" value="'.$key.'"><input type="hidden" name="delete_color" id="delete_color" value="'.$keyes.'"></td>';
				}
					$main_tr_td .= '<td>'.$count.'</td>
					<td>'.$key.'</td>
					<td>'.$keyes.'</td>';
					if(empty($viewMode)){
						$collapsCount = 4;
					}else{
						$collapsCount = 3;
					}
					$item_total_qty = $item_total_price = 0;
					$item_total_price = 0;
					foreach ($getDatabyStyle as $keysize => $valuesize) {
						if(array_key_exists($valuesize['Size'], $valuees)){
							$custom_size = $valuees[$valuesize['Size']]; 
							$item_total_price += $custom_size['TotalPrice'];
							$item_total_qty += $custom_size['QTYOrdered'];
							if($custom_size['Size'] == $valuesize['Size']){
								$main_tr_td .= '<td>'.$custom_size['QTYOrdered'].'</td>';
							}
						}else{
								$main_tr_td .= '<td></td>';	
						}
						$collapsCount ++;
					}
					$grandTotal += $item_total_price;
					$total_qty += $item_total_qty;
					$main_tr_td .= '<td>'.$item_total_qty.'</td><td>$'.number_format((float)$item_total_price,2).'</td>';
					if(empty($viewMode)){
						$main_tr_td .= '<td> <a href="javascript:void(0);" edit-id="'.$key.'" edit-color="'.$keyes.'" class="editOrderdItem newLinkText"><span class="fa fa-pencil"></span></a> <a class="newLinkText" href="javascript:void(0);"><span class="fa fa-close delSingalRecords"></span></a></td>';
					}

				$main_tr_td .='</tr><input type="hidden" name="grandTotal" id="grandTotal" value='.$grandTotal.' ><input type="hidden" name="qtyTotal" id="qtyTotal" value='.$total_qty.' >';
            	$renderHtml .= $main_tr_td;
            	$count ++;
				}
			}
		$getLoginCUstomerData = $this->getCustomerDetails();
		$FlatDiscount = number_format($getLoginCUstomerData[0]['FlatDiscount'],2);
		$FlatDic = explode('.',number_format($FlatDiscount,2));
		if(isset($FlatDic[1]) && $FlatDic[1] == 00){
			$FlatDiscount = $FlatDic[0];
		}
		$sellingprice = $grandTotal - ($grandTotal * ($FlatDiscount / 100));
		$DiscountAmount = $grandTotal * ($FlatDiscount / 100);

		$renderHtml .= '<tr>
				<td colspan="'.$collapsCount.'"></td>
				<td>'.$total_qty.'</td>
				<td>$'.number_format((float)$grandTotal,2).'</td>  
				<td></td>            
			</tr></table>';
		if(empty($viewMode)){
			$renderHtml .= '<div class="cf"><a href="javascript:void(0);" class="delSelectedRecords newLinkText">Delete Selected Rows</a></div>';
		}
		$renderHtml .= '<div class="cf"><div class="orderSummary"><div class="">Total Before Discount: <span class="labelValue">$'.number_format($grandTotal,2).'</span></div><div class="">Discount Applied: <span class="labelValue"> ('.$FlatDiscount.'%) - $'.number_format($DiscountAmount,2).'</span> </div><div class="">Freight/Handling<span class="labelValue">-</span> </div><div class="">Coupon/Campaign: <span class="labelValue">-</span> </div><div class="orderTotal">Total: <span class="labelValue">$'.number_format($sellingprice,2).'</span> </div></div></div>';
        }
		return $renderHtml;
	}
	public function newrenderOrderItemHtml($order_id = 0 , $style_number = '',$getColorCode = '',$viewMode = '',$groupstyle = '',$getDatabyStyle = array())
	{
		$query = "SELECT * FROM dbo.MWEB_Temp_RDR1 where BaseDoc = '".$order_id."' AND dbo.MWEB_Temp_RDR1.Style IN ('".$groupstyle."') ORDER BY dbo.MWEB_Temp_RDR1.Style ASC,dbo.MWEB_Temp_RDR1.ColorCode ASC";
		$getOrderData = $this-> getSapData($query);
		$renderHtml = "";
		if($getOrderData){
			$arraySize = $commanArray = array();
			//echo "<pre>";print_R($getOrderData)
			foreach ($getOrderData as $key => $value) {
					$arrayStyle['Style'][] = $value['Style'];
					$commanArray[$value['Style']][$value['ColorCode']][$value['Size']] = $value;
					//$getDatabyStyle[$value['SizeOrder']] = $value['Size'];	
					
				
			}
			if(empty($getDatabyStyle))
			{
				$getDatabyStyle = $this->getDatabyStyle($arrayStyle);	
				$tempgetdata = array();
				foreach ($getDatabyStyle as $key => $value) {
					$tempgetdata[$value['SizeOrder']] = $value['Size'];
				}
				$getDatabyStyle = $tempgetdata;
			}else{
				ksort($getDatabyStyle);
			}
			
			$header_one = '';
			$header_one .= '<table class="orderList lineItemsList"><tr>';
			if(empty($viewMode)){
				$header_one .= '<th width="30px"></th>';
			}
			$header_one .= '<th width="30px"></th>
						<th width="50px">Style #</th>
						<th width="50px">Color</th>';
			foreach ($getDatabyStyle as $key => $values) {
				$header_one .= '<th>'.$values.'</th>';
			}
			$header_one .= '<th width="50px">Qty.</th>
						<th width="70px">Total</th>
						<th width="50px"></th>
						</tr>';
            $renderHtml .= $header_one;
			/* Header size parts $header_one */
			$grandTotal = $total_qty = 0;
			$count = 1;

			foreach ($commanArray as $key => $value) {
				foreach ($value as $keyes => $valuees) {
				$main_tr_td = '<tr>';
				if(empty($viewMode)){
					$main_tr_td .= '<td><input type="checkbox" name="deleteMultiRecord[]" class="deleteMultiRecord" value="" /><input type="hidden" class="delete_style"id="delete_style_'.$key.'_'.$keyes.'" name="delete_style" value="'.$key.'"><input type="hidden" name="delete_color" class="delete_color" id="delete_color_'.$key.'_'.$keyes.'" value="'.$keyes.'"></td>';
				}
					$main_tr_td .= '<td>'.$count.'</td>
					<td>'.$key.'</td>
					<td>'.$keyes.'</td>';
					if(empty($viewMode)){
						$collapsCount = 4;
					}else{
						$collapsCount = 3;
					}
					$item_total_qty = $item_total_price = 0;
					$item_total_price = 0;
					foreach ($getDatabyStyle as $keysize => $valuesize) {
						if(array_key_exists($valuesize, $valuees)){
							$custom_size = $valuees[$valuesize]; 
							$item_total_price += (float)$custom_size['TotalPrice'];
							$item_total_qty += $custom_size['QTYOrdered'];
							if($custom_size['Size'] == $valuesize){
								$main_tr_td .= '<td>'.$custom_size['QTYOrdered'].'</td>';
							}
						}else{
								$main_tr_td .= '<td></td>';	
						}
						$collapsCount ++;
					}
					$grandTotal += $item_total_price;
					$total_qty += $item_total_qty;
					$main_tr_td .= '<td>'.$item_total_qty.'</td><td>$'.number_format((float)$item_total_price,2).'</td>';
					if(empty($viewMode)){
						$main_tr_td .= '<td> <a href="javascript:void(0);" edit-id="'.$key.'" edit-color="'.$keyes.'" class="editOrderdItem newLinkText"><span class="fa fa-pencil"></span></a> <a class="newLinkText" href="javascript:void(0);"><span class="fa fa-close delSingalRecords"></span></a></td>';
					}

				$main_tr_td .='</tr><input type="hidden" name="grandTotal" id="grandTotal_'.$key.'_'.$keyes.'" class="grandTotal" value='.$grandTotal.' ><input type="hidden" class="qtyTotal" name="qtyTotal" id="qtyTotal_'.$key.'_'.$keyes.'"" value='.$total_qty.' >';
            	$renderHtml .= $main_tr_td;
            	$count ++;
				}
			}
			$renderHtml .= '<tr>
				<td colspan="'.$collapsCount.'"></td>
				<td>'.$total_qty.'</td>
				<td>$'.number_format((float)$grandTotal,2).'</td>  
				<td></td></tr></table>';
		
		}
		return $renderHtml;
	}
	public function renderOrderItemHtmltotal($order_id = '' ,$viewMode = '')
	{
		$renderHtml = '';
		$FlatDiscount = '';
		//$gd_total = $this->getOrderSumItems($order_id);
		//$getLoginCUstomerData = $this->getCustomerDetails();
		$orderdata = $this->getidbyorderdata($order_id);
		if(!empty($orderdata[0]))
		{
			$grandTotal = $orderdata[0]['TotalBeforeDiscount'];
			//$FlatDiscount = number_format($orderdata[0]['DiscountPer'] + $orderdata[0]['TotalDiscountPer'] ,2);
			$FlatDiscount = number_format((float)$orderdata[0]['DiscountPer'] + (float)$orderdata[0]['TotalDiscountPer'] ,2);
			$sellingprice = $orderdata[0]['DocTotal'];
			$DiscountAmount = (float)$orderdata[0]['DiscountAmount'] + (float)$orderdata[0]['TotalDiscountAmount'];
			$orderdata = $orderdata[0];
		}
		if(!empty($FlatDiscount))
		{
			$FlatDic = explode('.',number_format($FlatDiscount,2));
			if(isset($FlatDic[1]) && $FlatDic[1] == 00){
				$FlatDiscount = $FlatDic[0];
			}	
		}
		
		if(!empty($grandTotal) && $grandTotal != 0 && $grandTotal != ''){
		if(empty($viewMode)){
			$renderHtml .= '<div class="cf"><a href="javascript:void(0);" class="delSelectedRecords newLinkText">Delete Selected Rows</a></div>';
		}
		$CouponCode = '-';
		if(!empty($orderdata['CouponCampaign']))
		{
			$CouponCode = $orderdata['CouponCampaign'];
		}
		$renderHtml .= '<div class="cf">
					<div class="orderSummary">
							<div class="">Total Before Discount: <span class="labelValue">$'.number_format($grandTotal,2).'</span></div>
							<div class="">Discount Applied: <span class="labelValue"> ('.$FlatDiscount.'%) - $'.number_format((float)$DiscountAmount,2).'</span> </div>
							<div class="">Freight/Handling<span class="labelValue">-</span> </div>
							<div class="">Coupon/Campaign: <span class="labelValue">'.$CouponCode.'</span> </div>
							<div class="orderTotal">Total: <span class="labelValue">$'.number_format($sellingprice,2).'</span> </div>
					</div>
					</div>';
		}
        return $renderHtml;
	}
	public function getSapOrders($CardCode = '', $po_number = '', $id = 0, $status = '', $date_from = '', $date_to = '')
    {
    	//$CardCode = '123494';
		if($CardCode == '')
		{
			return array();
		}
		$query = "SELECT mto.Id as Id, mto.WebOrderId as WebOrderId, mto.DocNum as DocNum, mto.CardCode as CardCode, mto.CardName as CardName,mto.ShippingStreetNo as ShippingStreetNo,mto.CreateDate as CreateDate, mto.NumatCardPo as NumatCardPo, mto.DocStatus as DocStatus, mto.TotalQTYUnits as TotalQTYUnits, mto.TotalOpen as TotalOpen, mto.TotalShipped as TotalShipped, mto.DocTotal as DocTotal, mto.DocStatus as DocStatus, mto.CardID as CardID, mto.BillingAddress as BillingAddress,mto.BillingName as BillingName, mto.BillingCity as BillingCity, mto.BillingState as  BillingState, mto.BillingStateCode as  BillingStateCode, mto.ShippingStateCode as  ShippingStateCode, mto.BillingCountry as BillingCountry, mto.BillingZip as BillingZip, mto.ShippingId as ShippingId, mto.ShippingAddress as ShippingAddress, mto.ShippingCity as ShippingCity, mto.ShippingState as ShippingState, mto.ShippingZip as ShippingZip, mto.ShippingCountry as ShippingCountry, mto.ShippingType as ShippingType , mto.DeliveryNotes as DeliveryNotes, mto.TotalBeforeDiscount as TotalBeforeDiscount, mto.ShippingCountryCode as ShippingCountryCode, 'T' as dataFrom, mto.CouponCampaign as CouponCampaign, '' as CouponCampaignRemark ,mto.BlindDropship as BlindDropship";
		
		$query .= " FROM dbo.MWEB_Temp_ORDR as mto ";
		
		$query .= " where CardCode = '".$CardCode."'";
		
		if($po_number != '')
			$query .= " and ( NumatCardPo = '" . $po_number . "' OR DocNum = '" . $po_number . "') ";
		if($id != '' && $id > 0)
			$query .= " and mto.Id = '" . $id . "'";
		if($status != '')
			$query .= " and DocStatus = '" . $status . "'";
		else
			$query .= " and DocStatus IN ('Submitted','Draft')";
		if($date_from != '' && $date_to != '')
			$query .= " and CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
		
		$query .= " UNION ";
		
		$query .= "SELECT  '' as Id, mo.WebOrderId as WebOrderId, mo.DocNum as DocNum, mo.CardCode as CardCode,mo.CardName as CardName,mo.ShippingStreetNo as ShippingStreetNo, mo.CreateDate as CreateDate, mo.NumatCardPo as NumatCardPo, mo.DocStatus as DocStatus, mo.TotalQTYUnits as TotalQTYUnits, mo.TotalOpen as TotalOpen, mo.TotalShipped as TotalShipped, mo.DocTotal as DocTotal, mo.DocStatus as DocStatus, mo.CardID as CardID, mo.BillingName as BillingName,mo.BillingAddress as BillingAddress, mo.BillingCity as BillingCity, mo.BillingState as BillingState, '' as  BillingStateCode, mo.ShippingState as  ShippingStateCode, mo.BillingCountry as BillingCountry, mo.BillingZip as BillingZip, mo.ShippingId as ShippingId, mo.ShippingAddress as ShippingAddress, mo.ShippingCity as ShippingCity, mo.ShippingState as ShippingState, mo.ShippingZip as ShippingZip, mo.ShippingCountry as ShippingCountry, mo.ShippingType as ShippingType , mo.DeliveryNotes as DeliveryNotes , mo.TotalBeforeDiscount as TotalBeforeDiscount, 'V' as dataFrom, mo.CouponCampaign as CouponCampaign, mo.CouponCampaignRemark as CouponCampaignRemark , mo.ShippingCountry as ShippingCountryCode,'' as BlindDropship";

		$query .= " FROM dbo.MWEB_ORDR as mo ";
		
		$query .= " where CardCode = '".$CardCode."'";
		
		
		if($po_number != '')
			$query .= " and ( NumatCardPo = '" . $po_number . "' OR DocNum = '" . $po_number . "') ";
		if($status != '')
			$query .= " and DocStatus = '" . $status . "'";
		if($date_from != '' && $date_to != '')
			$query .= " and  CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
		
		$query .= " ORDER BY CreateDate DESC";
		//echo $query;exit;
		return $this->getSapData($query);
    }
	public function getTotalSapOrderspage($CardCode = '', $po_number = '', $id = 0, $status = '', $date_from = '', $date_to = '', $order_by = 'CreateDate', $opt = 'DESC')
	{
		//$CardCode = '122151';
		if($CardCode == '')
		{
			return array();
		}
		
		if($status == 'Draft' || $status == 'Submitted' )
		{
			$query = "SELECT count(*) as P_Id ";
		
			$query .= " FROM dbo.MWEB_Temp_ORDR as mto ";
			
			$query .= " where CardCode = '".$CardCode."'";
			
			if($po_number != '')
				$query .= " and ( NumatCardPo LIKE '%" . $po_number . "%' OR DocNum LIKE '%" . $po_number . "%') ";
			if($id != '' && $id > 0)
				$query .= " and mto.Id = '" . $id . "'";
			if($status != '')
				$query .= " and DocStatus = '" . $status . "'";
			else
				$query .= " and DocStatus IN ('Submitted','Draft')";
			if($date_from != '' && $date_to != '')
				$query .= " and CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
		}
		else
		{
			$query = "SELECT count(*) as P_Id";
		
			$query .= " FROM dbo.MWEB_Temp_ORDR as mto ";
			$query .= " where CardCode = '".$CardCode."'";
			
			if($po_number != '')
				$query .= " and ( NumatCardPo LIKE '%" . $po_number . "%' OR DocNum LIKE '%" . $po_number . "%') ";
			if($id != '' && $id > 0)
				$query .= " and mto.Id = '" . $id . "'";
			if($status != '')
				$query .= " and DocStatus = '" . $status . "'";
			else
				$query .= " and DocStatus IN ('Submitted','Draft')";
			if($date_from != '' && $date_to != '')
				$query .= " and CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
			
			$query .= " UNION ";
			
			$query .= "SELECT  count(*) as P_Id ";

			if($po_number != '' || ($date_from != '' && $date_to != '') || $status != '')
			{
				$query .= " FROM dbo.MWEB_ORDR as mo ";
				$query .= " where CardCode = '".$CardCode."'";
			}else{
				$query .= " from dbo.[FN_MWEB_ORDR] ('".$CardCode."') as mo ";
				$query .= " where 1=1";
			
			}
			
			if($po_number != '')
				$query .= " and ( NumatCardPo LIKE '%" . $po_number . "%' OR DocNum LIKE '%" . $po_number . "%') ";
			if($status != '')
				$query .= " and DocStatus = '" . $status . "'";
			if($date_from != '' && $date_to != '')
				$query .= " and  CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
		}
		
		$select = ';WITH Results_CTE AS (
						SELECT
							*, ROW_NUMBER () OVER (

								ORDER BY ';
								
		if($order_by == 'CreateDate' && ($opt == 'DESC' || $opt == 'ASC' ))
		{
			$select .= ' CAST (t0.createdate AS datetime) '.$opt.',
					t0.docnum '.$opt;
		}
		else if(in_array($order_by, ['DocNum', 'TotalQTYUnits','TotalOpen','TotalShipped','DocTotal']) && ($opt == 'DESC' || $opt == 'ASC' ))
		{
			$select .= ' CAST( t0.'.$order_by.' AS FLOAT) '.$opt;
		}
		else
		{
			$select .= ' t0.'.$order_by.' '.$opt;
		}
									
		$select .= ' ) AS P_Id
						FROM
						( '.$query.' ) ';
						
		$select .= ' AS t0
						) SELECT
							*
						FROM
							Results_CTE ';
		 
		return $this->getSapData($query); 
	}
	public function getSapOrderspage($CardCode = '', $po_number = '', $id = 0, $status = '', $date_from = '', $date_to = '',$start_from = 0,$endform = 0, $order_by = 'CreateDate', $opt = 'DESC')
    {
    	if($CardCode == '')
		{
			return array();
		}
		if($status == 'Draft' || $status == 'Submitted' )
		{
			$query = "SELECT mto.Id as Id, mto.WebOrderId as WebOrderId, mto.DocNum as DocNum, mto.CardCode as CardCode, mto.CreateDate as CreateDate, mto.NumatCardPo as NumatCardPo, mto.DocStatus as DocStatus, mto.TotalQTYUnits as TotalQTYUnits, mto.TotalOpen as TotalOpen, mto.TotalShipped as TotalShipped, mto.DocTotal as DocTotal, mto.CardID as CardID, mto.BillingAddress as BillingAddress, mto.BillingCity as BillingCity, mto.BillingState as  BillingState, mto.BillingStateCode as  BillingStateCode, mto.ShippingStateCode as  ShippingStateCode, mto.BillingCountry as BillingCountry, mto.BillingZip as BillingZip, mto.ShippingId as ShippingId, mto.ShippingAddress as ShippingAddress, mto.ShippingCity as ShippingCity, mto.ShippingState as ShippingState, mto.ShippingZip as ShippingZip, mto.ShippingCountry as ShippingCountry, mto.ShippingType as ShippingType , mto.DeliveryNotes as DeliveryNotes, mto.TotalBeforeDiscount as TotalBeforeDiscount, 'T' as dataFrom, '' as CouponCampaign, '' as CouponCampaignRemark ";
		
			$query .= " FROM dbo.MWEB_Temp_ORDR as mto ";
			
			$query .= " where CardCode = '".$CardCode."'";
			
			if($po_number != '')
				$query .= " and ( NumatCardPo LIKE '%" . $po_number . "%' OR DocNum LIKE '%" . $po_number . "%') ";
			if($id != '' && $id > 0)
				$query .= " and mto.Id = '" . $id . "'";
			if($status != '')
				$query .= " and DocStatus = '" . $status . "'";
			else
				$query .= " and DocStatus IN ('Submitted','Draft')";
			if($date_from != '' && $date_to != '')
				$query .= " and CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
		}
		else
		{
			$query = '';
			if(strtolower($status) != strtolower('Processing'))
			{

			
			$query = "SELECT mto.Id as Id, mto.WebOrderId as WebOrderId, mto.DocNum as DocNum, mto.CardCode as CardCode, mto.CreateDate as CreateDate, mto.NumatCardPo as NumatCardPo, mto.DocStatus as DocStatus, mto.TotalQTYUnits as TotalQTYUnits, mto.TotalOpen as TotalOpen, mto.TotalShipped as TotalShipped, mto.DocTotal as DocTotal, mto.CardID as CardID, mto.BillingAddress as BillingAddress, mto.BillingCity as BillingCity, mto.BillingState as  BillingState, mto.BillingStateCode as  BillingStateCode, mto.ShippingStateCode as  ShippingStateCode, mto.BillingCountry as BillingCountry, mto.BillingZip as BillingZip, mto.ShippingId as ShippingId, mto.ShippingAddress as ShippingAddress, mto.ShippingCity as ShippingCity, mto.ShippingState as ShippingState, mto.ShippingZip as ShippingZip, mto.ShippingCountry as ShippingCountry, mto.ShippingType as ShippingType , mto.DeliveryNotes as DeliveryNotes, mto.TotalBeforeDiscount as TotalBeforeDiscount, 'T' as dataFrom, '' as CouponCampaign, '' as CouponCampaignRemark ";
		
			$query .= " FROM dbo.MWEB_Temp_ORDR as mto ";
			
			$query .= " where CardCode = '".$CardCode."'";
			
			if($po_number != '')
				$query .= " and ( NumatCardPo LIKE '" . $po_number . "%' OR DocNum LIKE '" . $po_number . "%') ";
			if($id != '' && $id > 0)
				$query .= " and mto.Id = '" . $id . "'";
			if($status != '')
				$query .= " and DocStatus = '" . $status . "'";
			else
				$query .= " and DocStatus IN ('Submitted','Draft')";
			if($date_from != '' && $date_to != '')
				$query .= " and CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
			
			$query .= " UNION ";
			}

			$query .= "SELECT '' as Id, mo.WebOrderId as WebOrderId, mo.DocNum as DocNum, mo.CardCode as CardCode, mo.CreateDate as CreateDate, mo.NumatCardPo as NumatCardPo, mo.DocStatus as DocStatus, mo.TotalQTYUnits as TotalQTYUnits, mo.TotalOpen as TotalOpen, mo.TotalShipped as TotalShipped, mo.DocTotal as DocTotal, mo.CardID as CardID, mo.BillingAddress as BillingAddress, mo.BillingCity as BillingCity, mo.BillingState as BillingState,'' as BillingStateCode,mo.ShippingState as ShippingStateCode, mo.BillingCountry as BillingCountry, mo.BillingZip as BillingZip, mo.ShippingId as ShippingId, mo.ShippingAddress as ShippingAddress, mo.ShippingCity as ShippingCity, mo.ShippingState as ShippingState, mo.ShippingZip as ShippingZip, mo.ShippingCountry as ShippingCountry, mo.ShippingType as ShippingType , mo.DeliveryNotes as DeliveryNotes , mo.TotalBeforeDiscount as TotalBeforeDiscount, 'V' as dataFrom, mo.CouponCampaign as CouponCampaign, mo.CouponCampaignRemark as CouponCampaignRemark ";

			if($po_number != '' || ($date_from != '' && $date_to != '') || $status != '')
			{
				$query .= " FROM dbo.MWEB_ORDR as mo ";
				$query .= " where CardCode = '".$CardCode."'";
			}else{
				$query .= " from dbo.[FN_MWEB_ORDR] ('".$CardCode."') as mo ";
				$query .= " where 1=1";
			
			}
			
			
			if($po_number != '')
				$query .= " and ( NumatCardPo LIKE '%" . $po_number . "%' OR DocNum LIKE '%" . $po_number . "%') ";
			if($status != '')
				$query .= " and DocStatus = '" . $status . "'";
			if($date_from != '' && $date_to != '')
				$query .= " and  CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
		}
		
		$select = ';WITH Results_CTE AS (
						SELECT
							*, ROW_NUMBER () OVER (

								ORDER BY';
		if($order_by == 'CreateDate' && ($opt == 'DESC' || $opt == 'ASC' ))
		{
			$select .= ' CAST (t0.createdate AS datetime) '.$opt.',
					t0.docnum '.$opt;
		}
		else if(in_array($order_by, ['DocNum', 'TotalQTYUnits','TotalOpen','TotalShipped','DocTotal']) && ($opt == 'DESC' || $opt == 'ASC' ))
		{
			$select .= ' CAST( t0.'.$order_by.' AS FLOAT) '.$opt;
		}
		else
		{
			$select .= ' t0.'.$order_by.' '.$opt;
		}
									
		$select .= ' ) AS P_Id
						FROM
						( '.$query.' ) ';
						
		$select .= ' AS t0
						) SELECT
							*
						FROM
							Results_CTE ';
		
		if($start_from >= 0 && $endform > 0)
		{
			$select .= " WHERE
							P_Id >= '".$start_from."'
						AND P_Id < '".$endform."'";
		}
		//echo $select;

		return $this->getSapData($select);
    }
	public function removePObyId($id = 0)
    {
		$customer = $this->_customerRepositoryInterface->getById($this->_session->getCustomer()->getId());
		//$getData = $this->_session->getCustomer()->getData();
		$customer_number = $customer->getCustomAttribute('customer_number')->getValue();
		
		$query = "SELECT Id FROM dbo.MWEB_Temp_ORDR WHERE dbo.MWEB_Temp_ORDR.Id = " . $id .  " AND dbo.MWEB_Temp_ORDR.DocStatus = 'Draft' AND dbo.MWEB_Temp_ORDR.CardCode = '" . $customer_number."'";
		$order_data = $this->getSapData($query);
		if(count($order_data) > 0)
		{
			$query = "DELETE FROM dbo.MWEB_Temp_ORDR WHERE dbo.MWEB_Temp_ORDR.Id = " . $id .  " AND dbo.MWEB_Temp_ORDR.DocStatus = 'Draft' AND dbo.MWEB_Temp_ORDR.CardCode = '" . $customer_number."'";
			$this->getSapData($query);
			$this->removePObyItems($id);
		}		
    }
	public function gettempOrdrstyle($order_id)
	{
		$query = "SELECT DISTINCT dbo.MWEB_Temp_RDR1.Style FROM dbo.MWEB_Temp_RDR1 WHERE dbo.MWEB_Temp_RDR1.BaseDoc = '".$order_id."'";
		return $this->getSapData($query);
	}
	public function getsizegroup($styles)
	{
		 $query = "SELECT DISTINCT dbo.MWEB_InventoryStatus.Style ,dbo.MWEB_InventoryStatus.SizeGroup   FROM dbo.MWEB_InventoryStatus  where dbo.MWEB_InventoryStatus.Style IN ('".$styles."') ORDER BY dbo.MWEB_InventoryStatus.SizeGroup ASC "; 
		return $this->getSapData($query);
	}
	
	public function deleteOrdreRecords($deleteArray = array(),$customer_number = '')
    { 
    	if($customer_number == '')
    	{
    		$customer = $this->_customerRepositoryInterface->getById($this->_session->getCustomer()->getId());
			$customer_number = $customer->getCustomAttribute('customer_number')->getValue();
		}
		if( isset($deleteArray) && isset($deleteArray['style']) && isset($deleteArray['color']) && count($deleteArray['style']) && count($deleteArray['color']) && isset($deleteArray['po_number']) )
		{

			$query_condition = "DELETE dbo.MWEB_Temp_RDR1 FROM dbo.MWEB_Temp_RDR1 INNER JOIN MWEB_Temp_ORDR ON dbo.MWEB_Temp_ORDR.Id = dbo.MWEB_Temp_RDR1.BaseDoc WHERE dbo.MWEB_Temp_ORDR.NumatCardPo = '" . $deleteArray['po_number'].  "' AND dbo.MWEB_Temp_ORDR.CardCode = '" . $customer_number.  "' AND (";
			$count = 0;
			foreach($deleteArray['style'] as $key => $style)
			{
				if($count > 0)
				{
					$query_condition .= " or ";
				}
				$query_condition .= " ( Style = '".$style."' and ColorCode = '". $deleteArray['color'][$key] ."' ) ";
				$count++;
			}
			$query_condition .= ")";
			$this->getSapData($query_condition);
			return $deleteArray['order_id'];
		}
		return '';
		
    }
	
	public function removePObyItems($po_id = 0, $item_array = array())
    {		
		$query = "DELETE FROM dbo.MWEB_Temp_RDR1 WHERE dbo.MWEB_Temp_RDR1.BaseDoc = ".$po_id;
		if(!empty($item_array))
		{
			$query .= " and ItemCode in ('".implode("','", $item_array)."') ";
		}
		//echo $query;exit;
		$this-> getSapData($query);
    }

    public function getDatabyItemCode($ItemCode)
    {
		$query = "SELECT * FROM dbo.MWEB_InventoryStatus  where dbo.MWEB_InventoryStatus.ItemCode = '".$ItemCode."'";
		return $this-> getSapData($query);
    }
    public function getSapOrdersData($customdata,$po_number)
    {
		$query = "SELECT * FROM dbo.MWEB_Temp_ORDR where dbo.MWEB_Temp_ORDR.CardCode = '".$customdata['CardCode']."' AND dbo.MWEB_Temp_ORDR.NumatCardPo = '".$po_number."' ";
		return $this-> getSapData($query);
    }
    public function getItemsData($order_id = "" , $ItemsSku = '')
	{
		$query = "SELECT * FROM dbo.MWEB_Temp_RDR1 where BaseDoc = '".$order_id."' AND ItemCode = '".$ItemsSku."' ORDER BY dbo.MWEB_Temp_RDR1.BaseDoc";
		return $this-> getSapData($query);
	}
	public function UpdateItemsData($itemsData)
	{
		if($itemsData['PriceAfterDiscount'] == '' || $itemsData['TotalPrice'] == '' || $itemsData['DiscountPer'])
    	{
    		$getitemsdata = $this->_session->getAllInventoryItems();
    		$skudata = $getitemsdata[$itemsData['ItemCode']];
    		if(!empty($skudata))
    		{
    			$itemsData['PriceAfterDiscount'] = number_format((float)$itemsData['QTYOrdered'] * $skudata['DisPrice'], 2, '.', '');
    			$itemsData['TotalPrice'] = $itemsData['PriceAfterDiscount'];
    			$itemsData['DiscountPer'] = isset($skudata['DisPercent']) ? $skudata['DisPercent'] : "";	
    		}
    		
    	}
		 $query = "UPDATE dbo.MWEB_Temp_RDR1 SET dbo.MWEB_Temp_RDR1.ItemCode = '".$itemsData['ItemCode']."', dbo.MWEB_Temp_RDR1.QTYOrdered = '".$itemsData['QTYOrdered']."',dbo.MWEB_Temp_RDR1.UnitPrice = '".$itemsData['UnitPrice']."',dbo.MWEB_Temp_RDR1.PriceAfterDiscount = '".$itemsData['PriceAfterDiscount']."',dbo.MWEB_Temp_RDR1.TotalPrice = '".$itemsData['TotalPrice']."', DiscountPer = '".$itemsData["DiscountPer"]."', DiscountPrice = '".$itemsData["DisPrice"]."' WHERE dbo.MWEB_Temp_RDR1.Id= '".$itemsData['id']."'";
		 
		return $this-> insertSapData($query);
	}
	public function InsertItemsData($data,$ItemData = array())
	{
		if(empty($ItemData))
		{
			$getColorStyleStatus = $this->getDatabyItemCode($data['ItemCode']);
    		$colorStatus = $getColorStyleStatus[0]['ColorStatus'];
    		$styleStatus = $getColorStyleStatus[0]['StyleStatus'];
    		$SizeOrder = $getColorStyleStatus[0]['SizeOrder'];
    		
		}else{
			$colorStatus = $ItemData['ColorStatus'];
    		$styleStatus = $ItemData['StyleStatus'];
    		$SizeOrder = $ItemData['SizeOrder'];
    	}
    	if($data['PriceAfterDiscount'] == '' || $data['TotalPrice'] == '' || $data['DiscountPer'])
    	{
    		$itemsdata = $this->_session->getAllInventoryItems();
    		$skudata = $itemsdata[$data['ItemCode']];
    		if(!empty($skudata))
    		{
    			$data['PriceAfterDiscount'] = number_format((float)$data['QTYOrdered'] * $skudata['DisPrice'], 2, '.', '');
    			$data['TotalPrice'] = $data['PriceAfterDiscount'];
    			$data['DiscountPer'] = isset($skudata['DisPercent']) ? $skudata['DisPercent'] : "";	
    		}
    		
    	}
		$query = "INSERT INTO dbo.MWEB_Temp_RDR1 (Style,ColorName,Size,BaseDoc,PriceAfterDiscount,TotalPrice,QTYOrdered,UnitPrice,ColorCode,ItemCode,ColorStatus,StyleStatus,SizeOrder,DiscountPer,DiscountPrice,OrderOption) VALUES('".$data['Style']."','".$data['ColorName']."','".$data['Size']."','".$data['BaseDoc']."','".$data['PriceAfterDiscount']."','".$data['TotalPrice']."','".$data['QTYOrdered']."','".$data['UnitPrice']."','".$data['ColorCode']."','".$data['ItemCode']."','".$colorStatus."','".$styleStatus."','".$SizeOrder."','".$data['DiscountPer']."','".$data['DisPrice']."','".$data['OrderOption']."')";
		
		return  $this-> insertSapData($query);
	} 
    
    public function getInvoicesData($cardCode,$status,$date_from,$date_to,$start_from,$endform, $order_by = 'CreateDate', $opt = 'DESC',$serachinvoice = '')
    {
    	if(($date_from != '' && $date_to != '') || $status != '' || $serachinvoice != '')
		{
			$query = "SELECT * FROM dbo.MWEB_OINV";
			$query .= " where CardCode = '".$cardCode."'";
		}else{
			$query = "SELECT * FROM dbo.FN_MWEB_OINV(".$cardCode.")";
			$query .= " where 1=1 ";
	
		}
		$oldstatus = '';
		if(strtolower($status) == strtolower('pastdue'))
		{
			$oldstatus = 'pastdue';
			$status = 'Open';

		}
		
		if($status == 'Open')
			$query .= " and DocStatus = '" . $status . "'";
		if($status == '1week')
		{
			$query .= " and CAST(DueDate AS DATE) BETWEEN '" . date("m-d-y") . "' AND  '" .date("m-d-y", strtotime("+1 week")) . "'";
		}
		if($status == '2week')
		{
			$query .= " and CAST(DueDate AS DATE) BETWEEN '" . date("m-d-y") . "' AND  '" .date("m-d-y", strtotime("+2 week")) . "'";
		}
		if($status == '1month')
		{
			$query .= " and CAST(DueDate AS DATE) BETWEEN '" . date("m-d-y") . "' AND  '" .date("m-d-y", strtotime("+1 month")) . "'";
		}
		if($oldstatus == 'pastdue')
		{
			$query .= " and CAST(DueDate AS DATE) <= '" . date("m-d-y") ."'";
		}
		if($serachinvoice != '')
		{
			$query .= " and  DocNum LIKE '%" . $serachinvoice . "%' ";
		}
		if($date_from != '' && $date_to != '')
			$query .= " and CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
		
		$select = ';WITH Results_CTE AS (
						SELECT
							*, ROW_NUMBER () OVER (

								ORDER BY ';
		if($order_by == 'CreateDate' && ($opt == 'DESC' || $opt == 'ASC' ))
		{
			$select .= ' CAST (t0.createdate AS datetime) '.$opt.',
					t0.docnum '.$opt;
		}
		else
		{
			$select .= ' t0.'.$order_by.' '.$opt;
		}
								
		$select .= ' ) AS P_Id
						FROM
						( '.$query.' ) ';
						
		$select .= ' AS t0
						) SELECT
							*
						FROM
							Results_CTE ';
		
		if($start_from >= 0 && $endform > 0)
		{
			$select .= " WHERE
							P_Id >= '".$start_from."'
						AND P_Id < '".$endform."'";
		}
		//echo $select;
		return $this->getSapData($select);
    }
    public function getInvoicesTotal($cardCode,$status,$date_from,$date_to, $order_by = 'CreateDate', $opt = 'DESC',$serachinvoice = '')
    { 
    	if(($date_from != '' && $date_to != '') || $status != '' || $serachinvoice != '')
		{
			$query = "SELECT count(*) as P_Id FROM dbo.MWEB_OINV";
			$query .= " where CardCode = '".$cardCode."'";
		}else{
			$query = "SELECT count(*) as P_Id FROM dbo.FN_MWEB_OINV(".$cardCode.")";
			$query .= " where 1=1 ";
	
		}
		$oldstatus = '';
		if($status == 'pastdue')
		{
			$oldstatus = 'pastdue';
			$status = 'Open';
		}
		if($status == 'Open')
			$query .= " and DocStatus = '" . $status . "'";
		if($status == '1week')
		{
			$query .= " and CAST(DueDate AS DATE) BETWEEN '" . date("m-d-y") . "' AND  '" .date("m-d-y", strtotime("+1 week")) . "'";
		}
		if($status == '2week')
		{
			$query .= " and CAST(DueDate AS DATE) BETWEEN '" . date("m-d-y"). "' AND  '" .date("m-d-y", strtotime("+2 week")) . "'";
		}
		if($status == '1month')
		{
			$query .= " and CAST(DueDate AS DATE) BETWEEN '" . date("m-d-y") . "' AND  '" .date("m-d-y", strtotime("+1 month")) . "'";
		}
		if($oldstatus == 'pastdue')
		{
			$query .= " and CAST(DueDate AS DATE) <= '" . date("m-d-y") ."'";
		}
		if($serachinvoice != '')
		{
			$query .= " and  DocNum LIKE '%" . $serachinvoice . "%' ";
		}
		if($date_from != '' && $date_to != '')
			$query .= " and CAST(CreateDate AS DATE) BETWEEN '" . $date_from . "' AND  '" . $date_to . "'";
		$select = ';WITH Results_CTE AS (
						SELECT
							*, ROW_NUMBER () OVER (

								ORDER BY ';
		if($order_by == 'CreateDate' && ($opt == 'DESC' || $opt == 'ASC' ))
		{
			$select .= ' CAST (t0.createdate AS datetime) '.$opt.',
					t0.docnum '.$opt;
		}
		else
		{
			$select .= ' t0.'.$order_by.' '.$opt;
		}
								
		$select .= ' ) AS P_Id
						FROM
						( '.$query.' ) ';
						
		$select .= ' AS t0
						) SELECT
							*
						FROM 
							Results_CTE ';
		/**echo $query;
		echo "<br>";
		echo "<br>";**/
		return $this->getSapData($query);
    }
     public function getInvoicesDetails($invoiceDocnum,$customer_number = '')
    {

    	if($customer_number == '')
    	{
    		$customerdata = $this->getCustomerDetails();
    		$customer_number = $customerdata[0]['CardCode'];
    	}
    	if(!empty($customer_number))
		{
			$query = "SELECT * FROM dbo.MWEB_OINV where dbo.MWEB_OINV.DocNum = $invoiceDocnum AND dbo.MWEB_OINV.CardCode = '".$customer_number."'";;
			return $this-> getSapData($query);
		}
		return '';
    }
    public function getInvoicesItemsDetails($invoiceDocnum)
    {
		$query = "SELECT * FROM dbo.MWEB_INV1 where dbo.MWEB_INV1.BaseDoc = ".$invoiceDocnum."ORDER BY dbo.MWEB_INV1.ItemCode ASC ";
		
		return $this-> getSapData($query);
    }
    public function getOrdersData($order_id, $data_from, $CardCode)
    {
    	if ($data_from == 'T')
		{
			$query = "SELECT mto.Id as Id, mto.WebOrderId as WebOrderId, mto.DocNum as DocNum, mto.CardCode as CardCode, mto.CreateDate as CreateDate, mto.NumatCardPo as NumatCardPo, mto.TotalQTYUnits as TotalQTYUnits, mto.TotalOpen as TotalOpen, mto.TotalShipped as TotalShipped, mto.DocTotal as DocTotal, mto.DocStatus as DocStatus, mto.CardID as CardID, mto.BillingAddress as BillingAddress, mto.BillingName as BillingName, mto.BillingCity as BillingCity, mto.BillingState as  BillingState, mto.BillingStateCode as  BillingStateCode, mto.ShippingStateCode as  ShippingStateCode, mto.BillingCountry as BillingCountry, mto.BillingZip as BillingZip, mto.ShippingId as ShippingId, mto.ShippingAddress as ShippingAddress, mto.ShippingCity as ShippingCity, mto.ShippingState as ShippingState, mto.ShippingZip as ShippingZip, mto.ShippingCountry as ShippingCountry, mto.ShippingType as ShippingType , mto.DeliveryNotes as DeliveryNotes, mto.TotalBeforeDiscount as TotalBeforeDiscount, 'T' as dataFrom , mto.DiscountPer as DiscountPer , mto.DiscountAmount as DiscountAmount, mto.FreightAmount as FreightAmount, mto.u_jk_order_method as u_jk_order_method, mto.CardName as CardName, mto.TotalDiscountPer as TotalDiscountPer, mto.TotalDiscountAmount as TotalDiscountAmount, '' as CouponCampaign, '' as CouponCampaignRemark, mto.ShippingStreetNo as ShippingStreetNo";
			
			$query .= " FROM dbo.MWEB_Temp_ORDR as mto ";
			
			$query .= " where Id = '".(int)$order_id."'";
			
			$query .= " AND DocStatus IN ('Submitted','Draft')";
		}
		else
		{
			$query = "SELECT  '' as Id, mo.WebOrderId as WebOrderId, mo.DocNum as DocNum, mo.CardCode as CardCode, mo.CreateDate as CreateDate, mo.NumatCardPo as NumatCardPo, mo.TotalQTYUnits as TotalQTYUnits, mo.TotalOpen as TotalOpen, mo.TotalShipped as TotalShipped, mo.DocTotal as DocTotal, mo.DocStatus as DocStatus, mo.CardID as CardID, mo.BillingAddress as BillingAddress, mo.BillingCity as BillingCity, mo.BillingState as BillingState, '' as BillingStateCode, mo.ShippingState as ShippingStateCode, mo.BillingCountry as BillingCountry, mo.BillingZip as BillingZip, mo.ShippingId as ShippingId, mo.ShippingAddress as ShippingAddress,mo.BillingName as BillingName, mo.ShippingCity as ShippingCity, mo.ShippingState as ShippingState, mo.Attn as Attn, '' as ShippingAddress2, mo.ShippingZip as ShippingZip, mo.ShippingCountry as ShippingCountry, mo.ShippingType as ShippingType , mo.DeliveryNotes as DeliveryNotes , mo.TotalBeforeDiscount as TotalBeforeDiscount, 'V' as dataFrom,mo.DeliveryDate as DeliveryDate, mo.DiscountPer as DiscountPer , mo.DiscountAmount as DiscountAmount, mo.FreightAmount as FreightAmount, mo.u_jk_order_method as u_jk_order_method, mo.CardName as CardName, mo.DocEntry as DocEntry ,mo.TotalDiscountPer as TotalDiscountPer, mo.TotalDiscountAmount as TotalDiscountAmount, mo.CouponCampaign as CouponCampaign, mo.CouponCampaignRemark as CouponCampaignRemark,mo.ShippingStreetNo as ShippingStreetNo"; 
			
			$query .= " FROM dbo.MWEB_ORDR as mo ";
			
			$query .= " where DocNum = '". (int)$order_id."'";
			
			$query .= " AND DocStatus NOT IN ('Submitted','Draft')";
		}
		$query .= " AND CardCode = '".$CardCode."' ";
		//echo $query;exit;
		return $this->getSapData($query);
    }
	
	public function getOrderDetailsItems($order_id, $data_from)
	{
		if($data_from == 'T')
			$query = "SELECT DISTINCT dbo.MWEB_Temp_RDR1.ColorCode ,
				SUM(cast(dbo.MWEB_Temp_RDR1.TotalPrice as decimal(18,6))) as TotalPrice,dbo.MWEB_Temp_RDR1.Style,
				SUM(cast(dbo.MWEB_Temp_RDR1.QTYOrdered as int)) as QTYOrdered,
				SUM(cast(dbo.MWEB_Temp_RDR1.DeliveredQTY as int)) as DeliveredQTY, 
				SUM(cast(dbo.MWEB_Temp_RDR1.OpenQTY as int)) as OpenQTY 
				FROM dbo.MWEB_Temp_RDR1  where dbo.MWEB_Temp_RDR1.BaseDoc = '".$order_id."' 
				group by dbo.MWEB_Temp_RDR1.ColorCode,dbo.MWEB_Temp_RDR1.Style";
		else
			$query = "SELECT DISTINCT dbo.MWEB_RDR1.ColorCode ,
				SUM(cast(dbo.MWEB_RDR1.TotalPrice as decimal(18,6))) as TotalPrice,dbo.MWEB_RDR1.Style,
				SUM(cast(dbo.MWEB_RDR1.QTYOrdered as int)) as QTYOrdered,
				SUM(cast(dbo.MWEB_RDR1.DeliveredQTY as int)) as DeliveredQTY, 
				SUM(cast(dbo.MWEB_RDR1.OpenQTY as int)) as OpenQTY
				FROM dbo.MWEB_RDR1  where dbo.MWEB_RDR1.DocNum = '".$order_id."' 
				group by dbo.MWEB_RDR1.ColorCode,dbo.MWEB_RDR1.Style";

		return $this-> getSapData($query);
	} 
	public function getInvoiceDetailsItems($invoiceDonnum)
	{
		$query = "SELECT * FROM dbo.MWEB_INV1  where dbo.MWEB_INV1.BaseDoc = '".$invoiceDonnum."' ORDER BY dbo.MWEB_INV1.Style ASC ,dbo.MWEB_INV1.ColorName ASC ,dbo.MWEB_INV1.SizeOrder ASC ";

			/**$query = "SELECT DISTINCT dbo.MWEB_INV1.ColorCode ,dbo.MWEB_INV1.ColorName  ,dbo.MWEB_INV1.UnitPrice,dbo.MWEB_INV1.DiscountPer,
				SUM(cast(dbo.MWEB_INV1.TotalPrice as decimal(18,6))) as TotalPrice,dbo.MWEB_INV1.Style,
				SUM(cast(dbo.MWEB_INV1.QTYOrdered as int)) as QTYOrdered
				FROM dbo.MWEB_INV1  where dbo.MWEB_INV1.BaseDoc = '".$invoiceDonnum."' 
				group by dbo.MWEB_INV1.ColorCode,dbo.MWEB_INV1.ColorName ,dbo.MWEB_INV1.UnitPrice,dbo.MWEB_INV1.DiscountPer,dbo.MWEB_INV1.Style";**/
		return $this-> getSapData($query);
	}
	public function getInvoiceExistingItems($invoiceDonnum = "" , $style = '',$getColorCode = "")
	{
		$query = "SELECT * FROM dbo.MWEB_INV1 where dbo.MWEB_INV1.BaseDoc = '".$invoiceDonnum."' AND dbo.MWEB_INV1.Style = '".$style."' AND dbo.MWEB_INV1.ColorCode = '".$getColorCode."' ORDER BY dbo.MWEB_INV1.Size";
		
		return $this-> getSapData($query);
	}
	public function getOrderItemsBySIze($order_id,$style,$getColorCode,$size, $data_from = 'T'){
			if($data_from == 'T')
			{
				$query = "SELECT * FROM dbo.MWEB_Temp_RDR1 where BaseDoc = '".(int)$order_id."' AND Style = '".$style."' AND ColorCode = '".$getColorCode."' AND Size = '".$size."' ORDER BY dbo.MWEB_Temp_RDR1.Size";
			}
			else
			{
				$query = "SELECT * FROM dbo.MWEB_RDR1 where DocNum = '".(int)$order_id."' AND Style = '".$style."' AND ColorCode = '".$getColorCode."' AND Size = '".$size."' ORDER BY dbo.MWEB_RDR1.Size";
			}
			return $this-> getSapData($query);
	}
	
	public function isOrderItemExist($entity_id,$style)
    {
		$query = "SELECT Id, Size,ColorCode FROM dbo.MWEB_Temp_RDR1 WHERE dbo.MWEB_Temp_RDR1.BaseDoc = '".$entity_id."' AND dbo.MWEB_Temp_RDR1.Style = '".$style."'";
		$data = $this->getSapData($query);
		return  $data;
    }
	
	public function updateDataOrderItems($data, $id)
    {
    	
    	if($data['PriceAfterDiscount'] == '' || $data['TotalPrice'] == '' || $data['DiscountPer'])
    	{
    		$itemsdata = $this->_session->getAllInventoryItems();
    		$skudata = $itemsdata[$data['itemscode']];
    		if(!empty($skudata))
    		{
    			$data['PriceAfterDiscount'] = number_format((float)$data['QTYOrdered'] * $skudata['DisPrice'], 2, '.', '');
    			$data['TotalPrice'] = $data['PriceAfterDiscount'];
    			$data['DiscountPer'] = isset($skudata['DisPercent']) ? $skudata['DisPercent'] : "";	
    		}
    		
    	}
		 $query = "UPDATE dbo.MWEB_Temp_RDR1 SET PriceAfterDiscount = '".$data["PriceAfterDiscount"]."', TotalPrice = '".$data["TotalPrice"]."', QTYOrdered = '".$data["QTYOrdered"]."', UnitPrice = '".$data["UnitPrice"]."', DiscountPer = '".$data["DiscountPer"]."', DiscountPrice = '".$data["DisPrice"]."' WHERE dbo.MWEB_Temp_RDR1.Id = '".$id."' AND dbo.MWEB_Temp_RDR1.BaseDoc = '".$data["BaseDoc"]."'";
		return  $this-> insertSapData($query);
    }

     public function getOrderRowStatus($order_id,$style,$getColorCode,$data_from = 'T'){
		if($data_from == 'T')
		{
			$query = "SELECT * FROM dbo.MWEB_Temp_RDR1 where Id = '".(int)$order_id."' AND Style = '".$style."' AND ColorCode = '".$getColorCode."' ORDER BY dbo.MWEB_Temp_RDR1.Size";
		}
		else
		{
			$query = "SELECT * FROM dbo.MWEB_RDR1 where DocNum = '".(int)$order_id."' AND Style = '".$style."' AND ColorCode = '".$getColorCode."' AND Style = '".$style."' ORDER BY dbo.MWEB_RDR1.Size";
		}
		return $this-> getSapData($query);
	}

	public function getOrderAllItems($order_id, $data_from) 
	{
		if($data_from == 'T')
		{
			$query = "SELECT * FROM dbo.MWEB_Temp_RDR1 where BaseDoc = '".(int)$order_id."' ORDER BY dbo.MWEB_Temp_RDR1.Style ASC, dbo.MWEB_Temp_RDR1.ColorName ASC , dbo.MWEB_Temp_RDR1.SizeOrder ASC";
		}
		else
		{
			$query = "SELECT * FROM dbo.MWEB_RDR1 where DocNum = '".(int)$order_id."' ORDER BY dbo.MWEB_RDR1.Style ASC, dbo.MWEB_RDR1.ColorName ASC , dbo.MWEB_RDR1.SizeOrder ASC";
		}
		return $this-> getSapData($query);
	}
	public function getTrackingInfo($DocEntry)
	{
		$query = "SELECT * FROM dbo.MWEB_TrackingInfo where SODocEntry = '".$DocEntry."'"; 
		return $this-> getSapData($query);
	}

	public function savePaymentInfo($data)
	{
		$query = "INSERT INTO dbo.MWEB_PaymentDetails (CreditCardNo,Exp_Month,Exp_Year,CardHolder_Name,Amount,Transaction_Id,AuthCode,Payment_Response, CreditCardType,createdt) VALUES('".$data['CardNumber']."','".$data['Exp_Month']."','".$data['Exp_Year']."','".$data['MethodName']."','".$data['amount']."','".$data['Transaction_Id']."','".$data['AuthCode']."','".$data['Payment_Response']."','".$data['CardType']."','".date("m-d-Y")."')";
		return  $this-> insertSapData($query);
	}
	public function getidbyorderdata($order_id)
	{
		$query = "SELECT * FROM dbo.MWEB_Temp_ORDR where dbo.MWEB_Temp_ORDR.Id = '".$order_id."'  ";
		return $this-> getSapData($query);
	}

	public function savePayInvoice($data)
	{
		$query = "INSERT INTO dbo.MWEB_Invoice (payment_Id,doc_entry,doc_no,customer_po,currentpaid,customer_code,customer_name,createdt) VALUES('".$data['payment_Id']."','".$data['doc_entry']."','".$data['doc_no']."','".$data['customer_po']."','".$data['currentpaid']."','".$data['customer_code']."','".$data['customer_name']."','".date("m-d-Y")."')";
		return  $this-> insertSapData($query);
	}
	
	function quoteString($value)
    {
        if (is_int($value)) {
            return $value;
        } elseif (is_float($value)) {
            return sprintf('%F', $value);
        }

        $value = addcslashes($value, "\000\032");
        return "'" . str_replace("'", "''", $value) . "'";
    }

    public function getStyleInventoryStatus($style)
    {		
		$query = "SELECT dbo.MWEB_InventoryStatus.ItemCode, dbo.MWEB_InventoryStatus.GroupCode, dbo.MWEB_InventoryStatus.GroupName, dbo.MWEB_InventoryStatus.Style, dbo.MWEB_InventoryStatus.ColorCode, dbo.MWEB_InventoryStatus.Color, dbo.MWEB_InventoryStatus.QtyAvailable, dbo.MWEB_InventoryStatus.ActualQty, dbo.MWEB_InventoryStatus.ETA, dbo.MWEB_InventoryStatus.ItemWeightOz, dbo.MWEB_InventoryStatus.StyleStatus, dbo.MWEB_InventoryStatus.ColorStatus, dbo.MWEB_InventoryStatus.UPC2, dbo.MWEB_InventoryStatus.ColorSwatch, dbo.MWEB_InventoryStatus.U_WImage1, dbo.MWEB_InventoryStatus.Collection, dbo.MWEB_InventoryStatus.UnitPrice, dbo.MWEB_InventoryStatus.Size, dbo.MWEB_InventoryStatus.SizeGroup, dbo.MWEB_InventoryStatus.Active, dbo.MWEB_InventoryStatus.SizeOrder, dbo.MWEB_InventoryStatus.DisPercent, dbo.MWEB_InventoryStatus.DisPrice FROM dbo.MWEB_InventoryStatus  where dbo.MWEB_InventoryStatus.Style = '".$style."' AND dbo.MWEB_InventoryStatus.ColorStatus <> 'Discontinued' AND dbo.MWEB_InventoryStatus.UnitPrice > 0 ORDER BY dbo.MWEB_InventoryStatus.Color ASC, dbo.MWEB_InventoryStatus.SizeOrder ASC ";
		
		return $this-> getSapData($query);
    }

    public function getpayinvoiceData($payinvoice = array())
    {
    	$payinvoice = "'".implode ("','", array_unique($payinvoice))."'";
		$query = "SELECT * FROM dbo.MWEB_Invoice  where doc_no IN (".$payinvoice.") AND SAPDocNo IS NULL";
		return $this-> getSapData($query);
    }
     public function getwebinv($itemsskus = array())
    {
    	$itemsskus = "'".implode ("','", array_unique($itemsskus))."'";
    	$query = "SELECT dbo.MWEB_InventoryStatus.ItemCode, dbo.MWEB_InventoryStatus.GroupCode, dbo.MWEB_InventoryStatus.GroupName, dbo.MWEB_InventoryStatus.Style, dbo.MWEB_InventoryStatus.ColorCode, dbo.MWEB_InventoryStatus.Color, dbo.MWEB_InventoryStatus.QtyAvailable, dbo.MWEB_InventoryStatus.ActualQty, dbo.MWEB_InventoryStatus.ETA, dbo.MWEB_InventoryStatus.ItemWeightOz, dbo.MWEB_InventoryStatus.StyleStatus, dbo.MWEB_InventoryStatus.ColorStatus, dbo.MWEB_InventoryStatus.UPC2, dbo.MWEB_InventoryStatus.ColorSwatch, dbo.MWEB_InventoryStatus.U_WImage1, dbo.MWEB_InventoryStatus.Collection, dbo.MWEB_InventoryStatus.UnitPrice, dbo.MWEB_InventoryStatus.Size, dbo.MWEB_InventoryStatus.SizeGroup, dbo.MWEB_InventoryStatus.Active, dbo.MWEB_InventoryStatus.SizeOrder, dbo.MWEB_InventoryStatus.DisPercent, dbo.MWEB_InventoryStatus.DisPrice FROM dbo.MWEB_InventoryStatus  where dbo.MWEB_InventoryStatus.ItemCode IN (".$itemsskus.") AND dbo.MWEB_InventoryStatus.UnitPrice > 0 ORDER BY dbo.MWEB_InventoryStatus.Color ASC, dbo.MWEB_InventoryStatus.SizeOrder ASC ";
		return $this-> getSapData($query);
    }
    
}	
