<?php
namespace ManishJoy\ChildCustomer\Logger;

class Logger extends \Monolog\Logger {
}