/**
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */

var config = {
    config: {
        mixins: {
            'jquery': {
                'Manadev_Core/js/mixins/jquery': true
            }
        }
    }
};