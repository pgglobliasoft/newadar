define(['Manadev_LayeredNavigation/js/ActionHelper'], function(ActionHelper) {
    return new ActionHelper();
});